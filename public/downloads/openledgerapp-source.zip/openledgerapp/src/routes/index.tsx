import { createFileRoute, redirect } from "@tanstack/react-router";

// Self-hosted edition: no public website. "/" opens the ledger (sign-in if needed).
export const Route = createFileRoute("/")({
  beforeLoad: () => {
    throw redirect({ to: "/ledger" });
  },
});
